adipart <-
function (...) 
{
   UseMethod("adipart")
}

